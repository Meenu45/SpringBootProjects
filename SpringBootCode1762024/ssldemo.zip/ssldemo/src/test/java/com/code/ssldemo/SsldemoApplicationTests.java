package com.code.ssldemo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SsldemoApplicationTests {

	@Test
	void contextLoads() {
	}

}
